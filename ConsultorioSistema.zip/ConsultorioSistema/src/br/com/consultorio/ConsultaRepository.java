/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.consultorio;
import br.com.consultorio.Consulta;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Gabriel
 */
public class ConsultaRepository {
  private static List<Consulta> lista = new ArrayList<>();

    public static void adicionar(Consulta c) {
        lista.add(c);
    }

    public static List<Consulta> listar() {
        return lista;
    }

    public static void remover(int indice) {
        lista.remove(indice);
    }
   
}
