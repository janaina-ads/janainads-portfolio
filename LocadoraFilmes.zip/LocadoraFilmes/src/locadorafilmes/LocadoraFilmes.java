/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package locadorafilmes;

/**
 *
 * @author Gabriel
 */
public class LocadoraFilmes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          TelaLogin login = new TelaLogin();
    login.setVisible(true);
}
    
}
