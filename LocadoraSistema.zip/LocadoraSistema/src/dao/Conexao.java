/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Gabriel
 */
public class Conexao {
   private static final String URL = "jdbc:mysql://localhost:3306/Atividade3";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection conectar() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Conexão realizada com sucesso!");

            return conn;

        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado: " + e.getMessage());

        } catch (SQLException e) {
            System.out.println("Erro SQL: " + e.getMessage());
        }

        return null;
    }
}