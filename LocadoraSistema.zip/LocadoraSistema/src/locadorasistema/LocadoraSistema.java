/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package locadorasistema;
import dao.ClienteDAO;
import model.Cliente;
import model.Filme;
import model.Locacao;

import java.util.Date;

/**
 *
 * @author Gabriel
 */
public class LocadoraSistema {

    /**
     * @param args the command line arguments
     */
 
    

      public static void main(String[] args) {
 
         
        Cliente cliente = new Cliente();
        cliente.setNome("Maria Silva");
        cliente.setCpf("12345678900");

        ClienteDAO clienteDAO = new ClienteDAO();
        clienteDAO.inserirCliente(cliente);

      
        Filme filme = new Filme();
        filme.setTitulo("Velozes e Furiosos");
        filme.setGenero("Ação");
        filme.setDisponivel(false);

        Locacao locacao = new Locacao();
        locacao.setCliente(cliente);
        locacao.setFilme(filme);
        locacao.setDataLocacao(new Date());

        System.out.println("=== SISTEMA LOCADORA ===");
        System.out.println("Cliente: " + cliente.getNome());
        System.out.println("CPF: " + cliente.getCpf());
        System.out.println("Filme: " + filme.getTitulo());
        System.out.println("Gênero: " + filme.getGenero());
        System.out.println("Data da locação: " + locacao.getDataLocacao());
        System.out.println("Status: Locação realizada com sucesso!");
    }
}
